# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'ed527ff76c97a3cafef2e95fcbacdf8c7b056459074d3228b625c193010ecdfe5d8180e577d11fb3350a6866efecac8603bd8130394120e00fad27c310f116cd'