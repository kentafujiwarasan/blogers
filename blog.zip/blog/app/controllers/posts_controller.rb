class PostsController < ApplicationController
  def new
    @post = Post.new
  end

  def create
    @user = current_user
    @posts = Post.all
    @post = Post.new(post_params)
    @post.user_id = current_user.id
    if @post.save
      flash[:notice] = 'You have created book successfully.'
      redirect_to post_path(@post.id)
    else
      render :index
    end
  end

  def index
    @posts = Post.all
    @post = Post.new
    @user = current_user


  end

  def show
    @post = Post.new
    @postb = Post.find(params[:id])
    @user = @postb.user

  end

  def edit
    @user = current_user
    @post = Post.find(params[:id])
    if @post.user.id != current_user.id
      redirect_to posts_path
    end
  end

  def update
    @user = current_user
    @post = Post.find(params[:id])
    if @post.update(post_params)
      flash[:notice] = 'You have updated book successfully.'
      redirect_to post_path(@post)
    else
      render :edit
    end
  end

  def destroy
    post = Post.find(params[:id])
    post.destroy
    redirect_to posts_path
  end

  private
  # ストロングパラメータ
  def post_params
    params.require(:post).permit(:title, :body)
  end

  def user_params
    params.require(:user).permit(:name, :introduction, :profile_image_id)
  end
end
